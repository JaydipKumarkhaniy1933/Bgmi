# ddos
# By JD @jdscript12